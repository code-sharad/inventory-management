const mongoose = require("mongoose")
require("dotenv").config()

const mongoURL = process.env.MONGOURL

mongoose.connect(mongoURL)
    
const db = mongoose.connection;

db.on("connected" , () => {
    console.log("Database connected successfully!!")
})

db.on('error' , (err) => {
    console.log("Error occured because of ",err)
})

db.on('disconnected' , () => {
    console.log("Database connection has disconnected")
})

module.exports = db;