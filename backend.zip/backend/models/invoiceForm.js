const mongoose = require("mongoose")

const invoiceFormSchema = new mongoose.Schema({
    companyName:{
        type:String,
        required:true
    },
    companyAddress:{
        type:String,
        required:true
    },
    cityStateZip:{
        type:String,
        required:true
    },
    phone:{
        type:String,
        required:true
    },
    email:{
        type:String,
        required:true
    },
    customerName:{
        type:String,
        required:true
    },
    customerEmail:{
        type:String,
        required:true
    },
    customerAddress:{
        type:String,
        required:true
    },
    invoiceNumber:{
        type:String,
        required:true,
        unique:true
    },
    invoiceDate:{
        type:Date,
        required:true
    }
})


const inventoryFormModel = new mongoose.model("inventoryFormModel" , invoiceFormSchema)

module.exports = inventoryFormModel

