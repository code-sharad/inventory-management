const express = require("express")
const cors = require("cors")
const bodyParser = require("body-parser")

const app = express()

app.use(cors({
    origin: "http://localhost:5173", // Your frontend URL (Vite default port)
    methods: ["GET", "POST", "PUT", "DELETE"],
    allowedHeaders: ["Content-Type"]
}));

app.use(bodyParser.json())


const db = require("./db")

app.get("/" , (req , res) => {
    res.send("backend is live")
})

const categoryRoute = require("./routes/categoryRoute")
const itemRoute = require("./routes/itemRoute")
const invoiceFormRoute = require("./routes/invoiceFormRoute")

app.use('/category' , categoryRoute)
app.use('/item',itemRoute)
app.use("/invoice-form",invoiceFormRoute)

app.listen(3000 , () => {
    console.log("server is running on port 3000")
})