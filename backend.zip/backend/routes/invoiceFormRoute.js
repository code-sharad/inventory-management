const express = require("express")
const router = express.Router()


const invoiceFormSchema = require("../models/invoiceForm")

router.post('/' , async (req , res) => {
    try{
        const data = req.body

        const invoiceForm = new invoiceFormSchema(data)
        const response = await invoiceForm.save()
        res.status(200).json(response)
        console.log("Data saved Succcessfully")
    }
    catch(e){
        res.status(400).json({ error: e.message });
    }
})

router.get('/', async (req , res) => {
    try{
        const item = await invoiceFormSchema.find()
        res.status(200).json(item)
        console.log("data fetched Successfully!!!")
    }
    catch(e){
        res.status(400).json({error:e.message})
    }
})


module.exports = router
